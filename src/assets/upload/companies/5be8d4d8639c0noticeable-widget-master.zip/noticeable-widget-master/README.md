## Noticeable Widget

![](https://firebasestorage.googleapis.com/v0/b/noticeable-service.appspot.com/o/users%2FwhM9Y7PbbDPTSs5SRyrtBZscbuj2%2Fprojects%2FZW6TLvP70GfMDgy9dHEX%2Fposts%2F151fcdb1-cf00-4e78-9d35-588db40c245d?alt=media&token=ffc498e2-7a98-4003-b57c-2a1891b7ede6)

This repository contains the `noticeable-widget` custom element
implementation. It is provided by [Noticeable](https://noticeable.io) 
to make product updates visible, improve user engagement and retention.
